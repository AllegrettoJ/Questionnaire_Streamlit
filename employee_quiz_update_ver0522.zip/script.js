import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.39.5/+esm";

const SUPABASE_URL = 'https://fajzrlqndlvniohzjviz.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZhanpybHFuZGx2bmlvaHpqdml6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc2OTcxMTMsImV4cCI6MjA2MzI3MzExM30.hlxM70telJXUlA8Y1AioZ-s1-rT0aZ-9GITmet3pEOw';
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

let currentEmployee = null;
let currentRound = 0;
let currentQuestions = [];
let answerDetails = [];

const loginForm = document.getElementById("loginForm");
const quizContainer = document.getElementById("quizContainer");
const mainPanel = document.createElement("div");
mainPanel.id = "mainPanel";
mainPanel.style.display = "none";
document.body.appendChild(mainPanel);

loginForm.addEventListener("submit", async function (e) {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const employeeId = document.getElementById("employeeId").value.trim();

  const { data, error } = await supabase
    .from("employees")
    .select("*")
    .eq("name", name)
    .eq("employee_id", employeeId)
    .single();

  if (error || !data) {
    document.getElementById("loginMessage").innerText = "Employee not found.";
    return;
  }

  currentEmployee = data;
  loginForm.style.display = "none";
  mainPanel.style.display = "block";
  showDashboard();
});

function showDashboard() {
  quizContainer.style.display = "none";
  mainPanel.innerHTML = `
    <h2>欢迎，${currentEmployee.name}</h2>
    <button id="checkScore">查询成绩</button>
    <button id="checkTotal">总成绩统计</button>
    <button id="startNextRound">开始下一轮答题</button>
    <div id="reportArea"></div>
  `;
  document.getElementById("checkScore").onclick = showScores;
  document.getElementById("checkTotal").onclick = showSummary;
  document.getElementById("startNextRound").onclick = startQuiz;
}

async function showScores() {
  const area = document.getElementById("reportArea");
  area.innerHTML = "<h3>每轮成绩</h3>";

  const { data: rounds } = await supabase
    .from("answers")
    .select("round, selected, correct, is_correct, question_id")
    .eq("employee_id", currentEmployee.employee_id.trim())
    .order("round", { ascending: true });

  rounds.forEach((r) => {
    const selected = JSON.parse(r.selected);
    const correct = JSON.parse(r.correct);
    const questionIds = r.question_id.split(",");

    const table = document.createElement("table");
    table.border = "1";
    table.style.marginBottom = "1rem";
    table.style.color = "white";
    table.style.borderCollapse = "collapse";

    const head = document.createElement("tr");
    questionIds.forEach((qid, i) => {
      const th = document.createElement("th");
      th.innerText = `Q${i + 1}`;
      head.appendChild(th);
    });
    const total = document.createElement("th");
    total.innerText = "总分";
    head.appendChild(total);
    table.appendChild(head);

    const resultRow = document.createElement("tr");
    questionIds.forEach((qid) => {
      const td = document.createElement("td");
      const correctAns = correct[qid];
      const userAns = selected[qid];
      td.innerText = userAns === correctAns ? "✔️" : "❌";
      resultRow.appendChild(td);
    });
    const totalCell = document.createElement("td");
    totalCell.innerText = r.is_correct;
    resultRow.appendChild(totalCell);

    table.appendChild(resultRow);

    const roundTitle = document.createElement("h4");
    roundTitle.innerText = `第 ${r.round} 轮`;
    area.appendChild(roundTitle);
    area.appendChild(table);
  });
}

async function showSummary() {
  const area = document.getElementById("reportArea");
  area.innerHTML = "<h3>汇总成绩</h3>";

  const { data: rounds } = await supabase
    .from("answers")
    .select("round, is_correct")
    .eq("employee_id", currentEmployee.employee_id.trim())
    .order("round", { ascending: true });

  const labels = rounds.map((r) => `第${r.round}轮`);
  const scores = rounds.map((r) => r.is_correct);

  const table = document.createElement("table");
  table.border = "1";
  table.style.color = "white";
  const header = document.createElement("tr");
  labels.forEach(l => {
    const th = document.createElement("th");
    th.innerText = l;
    header.appendChild(th);
  });
  table.appendChild(header);
  const row = document.createElement("tr");
  scores.forEach(s => {
    const td = document.createElement("td");
    td.innerText = `${s} 分`;
    row.appendChild(td);
  });
  table.appendChild(row);
  area.appendChild(table);

  const chartWrap = document.createElement("div");
  chartWrap.innerHTML = `
    <canvas id="totalBarChart"></canvas>
    <canvas id="totalPieChart" style="margin-top:1rem"></canvas>
  `;
  area.appendChild(chartWrap);

  new Chart(document.getElementById("totalBarChart"), {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{ data: scores, backgroundColor: '#4f81bd' }]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true, max: 10 } }
    }
  });

  const totalCorrect = scores.reduce((a, b) => a + b, 0);
  const totalQuestions = scores.length * 10;
  const totalWrong = totalQuestions - totalCorrect;

  new Chart(document.getElementById("totalPieChart"), {
    type: 'pie',
    data: {
      labels: ['答对', '答错'],
      datasets: [{
        data: [totalCorrect, totalWrong],
        backgroundColor: ['#4f81bd', '#f79646']
      }]
    }
  });

}

async function startQuiz() {
  const { data: records } = await supabase
    .from("answers")
    .select("round")
    .eq("employee_id", currentEmployee.employee_id.trim());

  let maxRound = 0;
  records?.forEach(r => { if (r.round > maxRound) maxRound = r.round; });
  currentRound = maxRound + 1;

  if (currentRound > 5) {
  const area = document.getElementById("reportArea");
  area.innerHTML = "<p>你已完成所有轮数。</p>";

  const returnBtn = document.createElement("button");
  returnBtn.textContent = "返回主页";
  returnBtn.onclick = () => {
    area.innerHTML = "";
    mainPanel.style.display = "block";
    showDashboard();
  };

  area.appendChild(returnBtn);
  return;
}


  mainPanel.style.display = "none";
  quizContainer.style.display = "block";

  const { data: questions } = await supabase
    .from("questions")
    .select("*")
    .eq("active", true)
    .order("id", { ascending: true });

  currentQuestions = questions.filter(q => q.group === currentRound);
  for (let i = currentQuestions.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [currentQuestions[i], currentQuestions[j]] = [currentQuestions[j], currentQuestions[i]];
  }
  renderQuestions();
}

function renderQuestions() {
  const area = document.getElementById("questionsArea");
  area.innerHTML = "";
  currentQuestions.forEach((q, index) => {
    const container = document.createElement("div");
    container.innerHTML = `<p>${index + 1}. ${q.question_text}</p>`;
    ["a", "b", "c", "d"].forEach(label => {
      const opt = document.createElement("div");
      opt.className = "option";
      opt.innerHTML = `<input type="radio" name="q${index}" value="${label}" id="q${index}${label}">
        <label for="q${index}${label}">${q[`option_${label}`]}</label>`;
      container.appendChild(opt);
    });
    area.appendChild(container);
  });
}

document.getElementById("quizForm").addEventListener("submit", async function (e) {
  e.preventDefault();
  const selected = {};
  let allAnswered = true;

  currentQuestions.forEach((q, index) => {
    const selectedOption = document.querySelector(`input[name="q${index}"]:checked`);
    if (selectedOption) selected[q.id || index] = selectedOption.value;
    else allAnswered = false;
  });

  if (!allAnswered) return alert("请完成所有题目后再提交。");

  let score = 0;
  const correctAnswers = {};
  answerDetails = [];

  currentQuestions.forEach((q, index) => {
    const qid = q.id || index;
    const correct = q.correct_option.trim().toLowerCase();
    const chosen = selected[qid];
    const isCorrect = chosen === correct;
    if (isCorrect) score++;
    correctAnswers[qid] = correct;
    answerDetails.push({
      question: q.question_text,
      selected: chosen,
      correct: correct,
      correctText: q[`option_${correct}`],
      isCorrect
    });
  });

  await supabase.from("answers").insert([{
    name: currentEmployee.name,
    employee_id: currentEmployee.employee_id.trim(),
    round: currentRound,
    submitted_at: new Date().toISOString(),
    question_id: currentQuestions.map(q => q.id).join(","),
    selected: JSON.stringify(selected),
    correct: JSON.stringify(correctAnswers),
    is_correct: score
  }]);

  await supabase.from("employees")
    .update({ current_round: currentRound, last_submit: new Date().toISOString() })
    .eq("employee_id", currentEmployee.employee_id.trim());

  quizContainer.style.display = "none";

  const message = document.createElement("div");
  message.id = "roundComplete";
  message.style.marginTop = "2rem";
  message.style.background = "#2a2a2a";
  message.style.padding = "1rem";
  message.style.borderRadius = "8px";
  message.style.textAlign = "center";
  message.innerHTML = `
    <p>你已完成第 ${currentRound} 轮，共 5 轮。本轮得分：${score}/10</p>
    <button id="viewScore">查看成绩详情</button>
    <button id="returnDashboard">返回个人页面</button>
  `;
  document.body.appendChild(message);

  document.getElementById("viewScore").addEventListener("click", () => {
    const detailBox = document.createElement("div");
    detailBox.style.marginTop = "1rem";
    detailBox.style.background = "#3a3a3a";
    detailBox.style.padding = "1rem";
    detailBox.style.borderRadius = "8px";
    answerDetails.forEach((item, i) => {
      const row = document.createElement("p");
      row.innerText = `${i + 1}. ${item.isCorrect ? "✅" : "❌"} 你的答案：${item.selected.toUpperCase()}，正确答案：${item.correct.toUpperCase()} - ${item.correctText}`;
      detailBox.appendChild(row);
    });

    const chartContainer = document.createElement("div");
    chartContainer.style.marginTop = "2rem";
    chartContainer.innerHTML = `
      <canvas id="barChart" height="100"></canvas>
      <canvas id="pieChart" height="100" style="margin-top: 2rem;"></canvas>
    `;
    detailBox.appendChild(chartContainer);
    message.appendChild(detailBox);

    const correctCount = answerDetails.filter(item => item.isCorrect).length;
    const incorrectCount = answerDetails.length - correctCount;

    new Chart(document.getElementById("barChart"), {
      type: 'bar',
      data: {
        labels: ['正确', '错误'],
        datasets: [{ label: '题数', data: [correctCount, incorrectCount], backgroundColor: ['#4f81bd', '#f79646'] }]
      },
      options: {
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, stepSize: 1, max: 10 } }
      }
    });

    new Chart(document.getElementById("pieChart"), {
      type: 'pie',
      data: {
        labels: ['答对', '答错'],
        datasets: [{ data: [correctCount, incorrectCount], backgroundColor: ['#4f81bd', '#f79646'] }]
      }
    });

    document.getElementById("viewScore").disabled = true;
  });

  document.getElementById("returnDashboard").onclick = () => {
  message.remove();
  quizContainer.style.display = "none";
  mainPanel.style.display = "block";
  mainPanel.innerHTML = "";
  showDashboard();
};

});
